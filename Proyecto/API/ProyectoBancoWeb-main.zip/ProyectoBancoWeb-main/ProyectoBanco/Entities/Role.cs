﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoBanco.Entities
{
    public class RolEnt
    {
        public int IdRol { get; set; }
        public string NombreRol { get; set; }
    }
}